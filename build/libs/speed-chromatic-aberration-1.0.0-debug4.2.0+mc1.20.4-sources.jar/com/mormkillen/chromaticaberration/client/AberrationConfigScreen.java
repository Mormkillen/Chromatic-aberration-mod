package com.mormkillen.chromaticaberration.client;

import com.mormkillen.chromaticaberration.AberrationConfig;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_5676;

/**
 * Config screen shown through Mod Menu. Vanilla widgets only — no Cloth
 * Config dependency. Changes apply live; the file is saved on Done.
 */
public class AberrationConfigScreen extends class_437 {
	private static final int ROW_WIDTH = 220;
	private static final int ROW_HEIGHT = 20;
	private static final int ROW_GAP = 26;

	private final class_437 parent;

	public AberrationConfigScreen(class_437 parent) {
		super(class_2561.method_43471("config.chromaticaberration.title"));
		this.parent = parent;
	}

	@Override
	protected void method_25426() {
		AberrationConfig config = AberrationConfig.get();
		int centerX = this.field_22789 / 2 - ROW_WIDTH / 2;
		int y = 60;

		// 1. Intensity multiplier slider (0% - 200%)
		this.method_37063(new IntensitySlider(centerX, y, ROW_WIDTH, ROW_HEIGHT, config));
		y += ROW_GAP;

		// 2. Disable the clean center zone
		this.method_37063(class_5676.method_32613(config.disableCenterDeadzone)
				.method_32617(centerX, y, ROW_WIDTH, ROW_HEIGHT,
						class_2561.method_43471("config.chromaticaberration.disable_center_deadzone"),
						(button, value) -> config.disableCenterDeadzone = value));
		y += ROW_GAP;

		// 3. Keep aberration visible while standing still
		this.method_37063(class_5676.method_32613(config.alwaysVisible)
				.method_32617(centerX, y, ROW_WIDTH, ROW_HEIGHT,
						class_2561.method_43471("config.chromaticaberration.always_visible"),
						(button, value) -> config.alwaysVisible = value));
		y += ROW_GAP;

		// 4. Ignore camera speed; slider controls intensity directly
		this.method_37063(class_5676.method_32613(config.disableSpeedScaling)
				.method_32617(centerX, y, ROW_WIDTH, ROW_HEIGHT,
						class_2561.method_43471("config.chromaticaberration.disable_speed_scaling"),
						(button, value) -> config.disableSpeedScaling = value));

		// Done
		this.method_37063(class_4185.method_46430(class_5244.field_24334, button -> this.method_25419())
				.method_46434(this.field_22789 / 2 - 100, this.field_22790 - 40, 200, ROW_HEIGHT)
				.method_46431());
	}

	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
		this.method_25420(context, mouseX, mouseY, delta);
		super.method_25394(context, mouseX, mouseY, delta);
		context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 20, 0xFFFFFF);
		context.method_27534(this.field_22793,
				class_2561.method_43471("config.chromaticaberration.intensity_hint"), this.field_22789 / 2, 36, 0xAAAAAA);
	}

	@Override
	public void method_25419() {
		AberrationConfig.get().save();
		if (this.field_22787 != null) {
			this.field_22787.method_1507(this.parent);
		}
	}

	private static final class IntensitySlider extends class_357 {
		private final AberrationConfig config;

		IntensitySlider(int x, int y, int width, int height, AberrationConfig config) {
			super(x, y, width, height, class_2561.method_43473(), config.intensityMultiplier / 2.0);
			this.config = config;
			this.method_25346();
		}

		@Override
		protected void method_25346() {
			this.method_25355(class_2561.method_43469("config.chromaticaberration.intensity", Math.round(this.field_22753 * 200)));
		}

		@Override
		protected void method_25344() {
			config.intensityMultiplier = (float) (this.field_22753 * 2.0);
		}
	}
}
