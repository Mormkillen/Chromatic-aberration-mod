package com.mormkillen.chromaticaberration;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3264;
import net.minecraft.class_3300;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mormkillen.chromaticaberration.client.AberrationRenderer;

public class ChromaticAberrationClient implements ClientModInitializer {
	public static final String MOD_ID = "chromaticaberration";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	private static final AberrationRenderer RENDERER = new AberrationRenderer();

	private static final String[] DEBUG_MODE_NAMES = {
			"0 · normal aberration",
			"1 · passthrough copy",
			"2 · force opaque alpha",
			"3 · visualize framebuffer alpha"
	};

	public static AberrationRenderer renderer() {
		return RENDERER;
	}

	@Override
	public void onInitializeClient() {
		// Recreate the post shader after a resource reload (F3+T),
		// otherwise the old GL program would keep stale shader code.
		ResourceManagerHelper.get(class_3264.field_14188).registerReloadListener(new SimpleSynchronousResourceReloadListener() {
			@Override
			public class_2960 getFabricId() {
				return new class_2960(MOD_ID, "shader_reload");
			}

			@Override
			public void method_14491(class_3300 manager) {
				RENDERER.onResourceReload();
			}
		});

		// Debug key: cycle shader debug modes (diagnosing the black-band issue).
		class_304 debugKey = KeyBindingHelper.registerKeyBinding(new class_304(
				"key.chromaticaberration.debug_mode",
				class_3675.class_307.field_1668,
				GLFW.GLFW_KEY_F8,
				"category.chromaticaberration"));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (debugKey.method_1436()) {
				int mode = RENDERER.cycleDebugMode();
				showActionbar(client, "Aberration debug mode: " + DEBUG_MODE_NAMES[mode]);
			}
		});

		LOGGER.info("Speed Chromatic Aberration initialized");
	}

	private static void showActionbar(class_310 client, String message) {
		if (client.field_1724 != null) {
			client.field_1724.method_7353(class_2561.method_43470(message), true);
		}
	}
}

